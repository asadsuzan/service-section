<?php
/**
 * Plugin Name: Services Section
 * Description: A service card block with multiple themes and an easy-to-use interface.
 * Version: 1.0.0
 * Author: bPlugins
 * Author URI: https://bplugins.com
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain: services-card-block
 */

namespace BPlugins\ServicesCard;

// Exit if accessed directly.
if (! defined('ABSPATH')) {
    exit;
}

// Constants.
define('Q3Q4SCB_VERSION', (isset($_SERVER['HTTP_HOST']) && 'localhost' === $_SERVER['HTTP_HOST']) ? time() : '1.0.0');
define('Q3Q4SCB_DIR_URL', plugin_dir_url(__FILE__));
define('Q3Q4SCB_DIR_PATH', plugin_dir_path(__FILE__));

if (! class_exists('Q3Q4ServiceCardPlugin')) {
    class Q3Q4ServiceCardPlugin
    {
        public function __construct()
        {
            add_action('init', [$this, 'onInit']);
            add_filter('manage_q3q4_service_card_posts_columns', [$this, 'cptColumns']);
            add_action('manage_q3q4_service_card_posts_custom_column', [$this, 'manageCptColumns'], 10, 2);
            add_shortcode('q3q4_service_card', [$this, 'serviceCardShortcode']);
            add_action('admin_enqueue_scripts', [$this, 'adminEnqueueScripts']);
			add_action('admin_menu', [$this, 'q3q4_add_demo_submenu']);

			// Plugin activation + redirect logic
              register_activation_hook( __FILE__, [$this,'q3q4_plugin_activate'] );
           	  add_action( 'admin_init', [$this,'q3q4_plugin_redirect'] );
        }

        public function onInit(): void
        {
            register_block_type(__DIR__ . '/build');
                register_post_type(
                'q3q4_service_card',
                [
                    'label'               => 'Service card',
                    'labels'              => [
						'add_new' => 'Add New',
						'add_new_item' => 'Add New Service',
						'edit_item' => 'Edit Service',
						'not_found' => 'There was no service please add one'
                        
                    ],
                    'show_in_rest' => true,
					'public' => true,
					'publicly_queryable' => false,
					'menu_icon' => 'dashicons-screenoptions',
					'item_published' => 'Service Card Block Published',
                    'item_updated' => 'Service Card Block Updated',
					'template' => [['services-card-block/services-cards']],
					// 'template_lock' => 'all',
                ]
            );
        }

			function q3q4_add_demo_submenu(){
				add_submenu_page(
					'edit.php?post_type=q3q4_service_card',
					'Demo and Help',
					'Demo & Help',
					'manage_options',
					'q3q4_demo_page',
					[$this, 'q3q4_render_demo_page']
				);
			}
			
			function q3q4_render_demo_page(){ 
				?>
					<div
						id='q3q4AdminDashboard'
						data-info='<?php echo esc_attr( wp_json_encode( [
							'version' => Q3Q4SCB_VERSION,
							'isPremium' => false,
							'hasPro' => false,
						] ) ); ?>'
					></div>
				<?php
			}


        public function manageCptColumns(string $columnName, int $postId): void
        {
            if ('shortcode' === $columnName) {
                echo '<div class="bPlAdminShortcode" id="bPlAdminShortcode-' . esc_attr($postId) . '">
                        <input value="[q3q4_service_card id=' . esc_attr($postId) . ']" onclick="copyBPlAdminShortcode(\'' . esc_attr($postId) . '\')" readonly>
                        <span class="tooltip">Copy To Clipboard</span>
                      </div>';
            }

            if ('publisher' === $columnName) {
                echo 'bplugins';
            }
        }

        public function displayContent(\WP_Post $post): string
        {
            $blocks = parse_blocks($post->post_content);
            return render_block($blocks[0]);
        }

        public function cptColumns(array $columns): array
        {
            unset($columns['date']);
            $columns['shortcode'] = 'Shortcode';
            $columns['date']      = 'Date';
            $columns['publisher'] = 'Publisher';
            return $columns;
        }

   
       	function serviceCardShortcode($atts){
				
				if (!isset($atts['id'])) {
					$attr_string = '';
					foreach ($atts as $key => $value) {
						$attr_string .= $key . '="' . esc_attr($value) . '" ';
					}
					$shortcode = '[bypass_audio_player ' . trim($attr_string) . ']';
					return do_shortcode($shortcode);
				}

				$post_id = $atts['id'];
				$post = get_post( $post_id );

				if ( !$post ) {
					return '';
				}

				if ( post_password_required( $post ) ) {
					return get_the_password_form( $post );
				}

				switch ( $post->post_status ) {
					case 'publish':
						return $this->displayContent( $post );
						
					case 'private':
						if (current_user_can('read_private_posts')) {
							return $this->displayContent( $post );
						}
						return '';
						
					case 'draft':
					case 'pending':
					case 'future':
						if ( current_user_can( 'edit_post', $post_id ) ) {
							return $this->displayContent( $post );
						}
						return '';
						
					default:
						return '';
				}
			}

        public function adminEnqueueScripts($screen): void
        {
           	global $typenow;

				if ('q3q4_service_card' === $typenow) {
					
					wp_enqueue_script( 'admin-post-js', Q3Q4SCB_DIR_URL . 'build/admin-post.js', [], Q3Q4SCB_VERSION, true );
					wp_enqueue_style( 'admin-post-css', Q3Q4SCB_DIR_URL . 'build/admin-post.css', [], Q3Q4SCB_VERSION );

					if ($screen === "q3q4_service_card_page_q3q4_demo_page") {
						wp_enqueue_script( 'bpl-admin-dashboard-js', Q3Q4SCB_DIR_URL . 'build/admin-dashboard.js', [ 'react', 'react-dom' ], Q3Q4SCB_VERSION, true );
						wp_enqueue_style( 'bpl-admin-dashboard-css', Q3Q4SCB_DIR_URL . 'build/admin-dashboard.css', [], Q3Q4SCB_VERSION );
					}

				}
        }

		  	//plugin activate
		function q3q4_plugin_activate() {
		set_transient('_q3q4_do_activation_redirect', true, 30);
		}

		//plugin  redirect
		function q3q4_plugin_redirect() {
              if ( get_transient( '_q3q4_do_activation_redirect' ) ) {
              delete_transient( '_q3q4_do_activation_redirect' );

        // Skip redirect if multiple plugins activated
        if ( isset( $_GET['activate-multi'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return;
        }

      // Redirect to service card layout post type
				wp_safe_redirect(
					admin_url('edit.php?post_type=q3q4_service_card&page=q3q4_demo_page')
				);
				exit;
    }
}






    }

    new Q3Q4ServiceCardPlugin();
}
